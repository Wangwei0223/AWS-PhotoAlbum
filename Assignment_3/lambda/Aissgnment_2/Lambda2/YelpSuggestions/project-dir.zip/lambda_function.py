import json
import requests

def lambda_handler(event, context):
    # TODO implement
    API_HOST = 'https://api.yelp.com'
    BUSINESS_PATH = '/v3/businesses/'
    business_path = BUSINESS_PATH + 'la-taqueria-san-francisco-2'
    url = API_HOST + business_path + '/reviews'
    headers = {'Authorization': "Bearer yCJwgghotXSwTYCGhYtNmfuMlMqYZ28pXTEMNGyvFRCANjY_NoE2VspNRjQr0NhCB9zpNCigqDJa2Bnlm5ARmUWdiuzYabZBTIoZ0A0IDd-E3fqdcvALHhGE0XbnW3Yx"}

    response = requests.get(url, headers=headers)
    print(response.json())
    return {
        'statusCode': 200,
        'body': response.json()
    }